import pandas as pd
# Load the marketing campaign dataset
url = "https://raw.githubusercontent.com/ArchanaInsights/Datasets/main/marketing_campaign.csv"

df = pd.read_csv(url)
# Printing first 5 rows from the data set
print("Dataset loaded successfully!")
print(df.head())
# Display first 5 rows
print("First 5 rows of the dataset:")
print(df.head())
# Display number of rows and columns
print("\nNumber of Rows and Columns:")
print(df.shape)
# Display dataset information
print("\nDataset Information:")
df.info()
# Generate descriptive statistics
print("\nDescriptive Statistics:")
print(df.describe())
# Count unique Campaign IDs
print("\nNumber of Unique Campaign IDs:")
print(df['Campaign_ID'].nunique())
# Display unique locations
print("\nUnique Locations:")
print(df['Location'].unique())

# Display unique customer segments
print("\nUnique Customer Segments:")
print(df['Customer_Segment'].unique())
# Count Campaign Types and Channels

# Remove extra spaces from column names
df.columns = df.columns.str.strip()

# Campaign Type Counts
print("\nCampaign Type Counts:")
print(df['Campaign_Type'].value_counts())

# Identify the actual Channel column
channel_columns = [col for col in df.columns if 'channel' in col.lower()]

print("\nMatching Channel Column Names:")
print(channel_columns)

# Count channel occurrences
if channel_columns:
    print("\nChannel Used Counts:")
    print(df[channel_columns[0]].value_counts())
else:
    print("\nChannel column not found!")
    print("Available columns:", df.columns.tolist())
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
# 1. Scatter Plot: Acquisition Cost vs ROI

plt.figure(figsize=(8, 5))

sns.scatterplot(
    data=df,
    x='Acquisition_Cost',
    y='ROI'
)

plt.title('Relationship Between Acquisition Cost and ROI')
plt.xlabel('Acquisition Cost')
plt.ylabel('Return on Investment (ROI)')
plt.grid(True)

plt.show()
# 2. Bar Chart: Average Conversion Rate
# Identify the actual channel column name
channel_col = next(
    col for col in df.columns
    if 'channel' in col.lower()
)
plt.figure(figsize=(12, 6))
sns.barplot(
    data=df,
    x=channel_col,
    y='Conversion_Rate',
    hue='Campaign_Type',
    errorbar=None
)
plt.title('Average Conversion Rate by Channel and Campaign Type')
plt.xlabel('Channel Used')
plt.ylabel('Average Conversion Rate')
plt.xticks(rotation=45)
plt.legend(title='Campaign Type')
plt.tight_layout()
plt.show()
# 3. Box Plot: Engagement Score by Campaign Type

plt.figure(figsize=(10, 6))

sns.boxplot(
    data=df,
    x='Campaign_Type',
    y='Engagement_Score'
)

plt.title('Engagement Score Distribution by Campaign Type')
plt.xlabel('Campaign Type')
plt.ylabel('Engagement Score')
plt.xticks(rotation=30)

plt.tight_layout()
plt.show()
# 4. Bar Chart: Average ROI by Company

company_roi = df.groupby('Company')['ROI'].mean().sort_values(ascending=False)

plt.figure(figsize=(12, 6))

sns.barplot(
    x=company_roi.index,
    y=company_roi.values
)

plt.title('Average ROI by Company')
plt.xlabel('Company')
plt.ylabel('Average ROI')
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()
# 5. Heatmap: Correlation Analysis

correlation = df[['Engagement_Score', 'Conversion_Rate']].corr()

plt.figure(figsize=(7, 5))

sns.heatmap(
    correlation,
    annot=True,
    cmap='coolwarm',
    fmt='.2f',
    linewidths=0.5
)

plt.title('Correlation Between Engagement Score and Conversion Rate')

plt.show()
# 1. Count Plot: Target Audience Distribution

plt.figure(figsize=(12, 6))

sns.countplot(
    data=df,
    x='Target_Audience',
    order=df['Target_Audience'].value_counts().index
)

plt.title('Distribution of Target Audience')
plt.xlabel('Target Audience')
plt.ylabel('Number of Campaigns')
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()
# 2. Bar Chart: Conversion Rate by Language
# and Customer Segment

segment_conversion = df.groupby(
    ['Language', 'Customer_Segment']
)['Conversion_Rate'].mean().reset_index()

plt.figure(figsize=(12, 6))

sns.barplot(
    data=segment_conversion,
    x='Language',
    y='Conversion_Rate',
    hue='Customer_Segment',
    errorbar=None
)

plt.title('Average Conversion Rate by Customer Segment and Language')
plt.xlabel('Language')
plt.ylabel('Average Conversion Rate')

plt.legend(
    title='Customer Segment',
    bbox_to_anchor=(1.05, 1),
    loc='upper left'
)

plt.tight_layout()

# Save chart as an image
plt.savefig('Customer_Segment_Conversion.png', dpi=300)

plt.show()
plt.close()

# Display highest conversion segment for each language
highest_conversion = segment_conversion.loc[
    segment_conversion.groupby('Language')['Conversion_Rate'].idxmax()
]

print("\nHighest Converting Customer Segment for Each Language:")
print(highest_conversion)
# 3. Box Plot: Acquisition Cost by Customer Segment and Channel

plt.figure(figsize=(13, 6))

sns.boxplot(
    data=df,
    x='Customer_Segment',
    y='Acquisition_Cost',
    hue=channel_col
)

plt.title('Acquisition Cost by Customer Segment and Channel')
plt.xlabel('Customer Segment')
plt.ylabel('Acquisition Cost')
plt.xticks(rotation=30)

plt.legend(title='Channel Used', bbox_to_anchor=(1.05, 1), loc='upper left')

plt.tight_layout()
plt.show()
# 4. Bar Chart: Average Conversion Rate by Language

language_conversion = df.groupby('Language')['Conversion_Rate'].mean().sort_values(
    ascending=False
)

plt.figure(figsize=(8, 5))

sns.barplot(
    x=language_conversion.index,
    y=language_conversion.values
)

plt.title('Average Conversion Rate by Language')
plt.xlabel('Language')
plt.ylabel('Average Conversion Rate')

plt.tight_layout()
plt.show()

print("\nAverage Conversion Rate by Language:")
print(language_conversion)
# 1. Bar Chart - Engagement Score by Channel and Campaign Type

# Identify the channel column dynamically
channel_col = [col for col in df.columns if 'channel' in col.lower()][0]

plt.figure(figsize=(12, 6))

sns.barplot(
    data=df,
    x=channel_col,
    y='Engagement_Score',
    hue='Campaign_Type',
    ci=None
)

plt.title('Engagement Score by Channel and Campaign Type')
plt.xlabel('Channels Used')
plt.ylabel('Average Engagement Score')
plt.xticks(rotation=45)
plt.legend(title='Campaign Type')
plt.tight_layout()
plt.show()

# 2. Pie Chart - Total ROI by Channel

# Calculate total ROI for each channel
channel_roi = df.groupby(channel_col)['ROI'].sum()

plt.figure(figsize=(8, 8))

plt.pie(
    channel_roi,
    labels=channel_roi.index,
    autopct='%1.1f%%',
    startangle=90
)

plt.title('Total ROI Distribution Across Marketing Channels')
plt.tight_layout()
plt.show()


# 3. Scatter Plot - Clicks vs Impressions by Channel

plt.figure(figsize=(10, 6))

sns.scatterplot(
    data=df,
    x='Impressions',
    y='Clicks',
    hue=channel_col,
    alpha=0.7,
    s=60
)

plt.title('Relationship Between Clicks and Impressions by Channel')
plt.xlabel('Number of Impressions')
plt.ylabel('Number of Clicks')
plt.legend(title='Channels Used')
plt.tight_layout()
plt.show()

# Convert Date column into datetime format
df['Date'] = pd.to_datetime(df['Date'], format='%d-%m-%Y')

# Sort data by Date
df = df.sort_values(by='Date')

# Check the data type
print(df['Date'].dtype)

# Display first 5 rows
print(df[['Date']].head())
# 1. Histogram - Distribution of Duration

plt.figure(figsize=(10, 6))

sns.histplot(
    data=df,
    x='Duration',
    bins=15,
    kde=True
)

plt.title('Distribution of Marketing Campaign Duration')
plt.xlabel('Campaign Duration (Days)')
plt.ylabel('Number of Campaigns')

plt.tight_layout()
plt.show()

# 2. Line Chart - Conversion Rate over Date for each Company

# Calculate average conversion rate by Date and Company
conversion_trend = df.groupby(
    ['Date', 'Company']
)['Conversion_Rate'].mean().reset_index()

plt.figure(figsize=(12, 6))

sns.lineplot(
    data=conversion_trend,
    x='Date',
    y='Conversion_Rate',
    hue='Company',
    marker='o'
)

plt.title('Conversion Rate Trend Over Time for Each Company')
plt.xlabel('Date')
plt.ylabel('Average Conversion Rate')
plt.xticks(rotation=45)
plt.legend(title='Company')
plt.tight_layout()
plt.show()

# 3. Line Chart - Engagement Score Trend Over Date

# Calculate average engagement score for each date
engagement_trend = df.groupby(
    'Date'
)['Engagement_Score'].mean().reset_index()

plt.figure(figsize=(12, 6))

sns.lineplot(
    data=engagement_trend,
    x='Date',
    y='Engagement_Score',
    marker='o'
)

plt.title('Engagement Score Trend Over Time')
plt.xlabel('Date')
plt.ylabel('Average Engagement Score')
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

# 1. Bar Chart - Acquisition Cost by Location

# Calculate total acquisition cost for each location
location_cost = df.groupby('Location')['Acquisition_Cost'].sum().reset_index()

# Find the location with the highest acquisition cost
highest_cost = location_cost.loc[location_cost['Acquisition_Cost'].idxmax()]

print("Location with Highest Acquisition Cost:")
print(highest_cost)

# Create bar chart
plt.figure(figsize=(10, 6))

sns.barplot(
    data=location_cost,
    x='Location',
    y='Acquisition_Cost',
    errorbar=None
    )

plt.title('Total Acquisition Cost by Location')
plt.xlabel('Location')
plt.ylabel('Total Acquisition Cost')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 2. Grouped Bar Chart - Conversion Rate by Location and Target Audience

# Calculate average conversion rate
location_conversion = df.groupby(
    ['Location', 'Target_Audience']
)['Conversion_Rate'].mean().reset_index()

plt.figure(figsize=(12, 6))

sns.barplot(
    data=location_conversion,
    x='Location',
    y='Conversion_Rate',
    hue='Target_Audience',
    errorbar=None
)

plt.title('Conversion Rate by Location and Target Audience')
plt.xlabel('Location')
plt.ylabel('Average Conversion Rate')
plt.xticks(rotation=45)
plt.legend(title='Target Audience')
plt.tight_layout()
plt.show()

# 3. Pie Chart - ROI Distribution by Location

# Calculate total ROI for each location
location_roi = df.groupby('Location')['ROI'].sum()

plt.figure(figsize=(9, 9))

plt.pie(
    location_roi,
    labels=location_roi.index,
    autopct='%1.1f%%',
    startangle=90
)

plt.title('ROI Distribution Across Different Locations')
plt.tight_layout()
plt.show()